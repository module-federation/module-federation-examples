exports.id = 522;
exports.ids = [522];
exports.modules = {

/***/ 17522:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(71352);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);


var SomeComponent = function SomeComponent() {
  return /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", {
    style: {
      padding: "1em",
      margin: "1em",
      border: "1px solid black",
      backgroundColor: "#ccc"
    },
    onClick: function onClick() {
      return alert("website2 is interactive");
    }
  }, "Header from website2. You can change this and reload localhost:3001 - the changes take old on SSR and client side");
};

/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (SomeComponent);

/***/ })

};
;