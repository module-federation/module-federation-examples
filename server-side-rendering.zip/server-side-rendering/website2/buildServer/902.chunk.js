exports.id = 902;
exports.ids = [902];
exports.modules = {

/***/ 89671:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "default": () => /* binding */ render
});

// EXTERNAL MODULE: consume shared module (default) react@^16.8.6 (strict) (fallback: ../../node_modules/react/index.js)
var index_js_ = __webpack_require__(71352);
var index_js_default = /*#__PURE__*/__webpack_require__.n(index_js_);

// EXTERNAL MODULE: ../../node_modules/react-dom/server.js
var server = __webpack_require__(5804);
// EXTERNAL MODULE: ../../node_modules/react-helmet/es/Helmet.js
var Helmet = __webpack_require__(18671);
// EXTERNAL MODULE: ../../node_modules/@loadable/server/lib/index.js
var lib = __webpack_require__(70453);
// EXTERNAL MODULE: external "path"
var external_path_ = __webpack_require__(85622);
var external_path_default = /*#__PURE__*/__webpack_require__.n(external_path_);

// CONCATENATED MODULE: ./src/components/SomeComponent.js


var SomeComponent = function SomeComponent() {
  return /*#__PURE__*/index_js_default().createElement("div", {
    style: {
      padding: "1em",
      margin: "1em",
      border: "1px solid black",
      backgroundColor: "#ccc"
    },
    onClick: function onClick() {
      return alert("website2 is interactive");
    }
  }, "Header from website2. You can change this and reload localhost:3001 - the changes take old on SSR and client side");
};

/* harmony default export */ const components_SomeComponent = (SomeComponent);
// CONCATENATED MODULE: ./src/components/App.js


/* harmony default export */ const App = (function () {
  return /*#__PURE__*/index_js_default().createElement("div", null, /*#__PURE__*/index_js_default().createElement(components_SomeComponent, null));
});
// CONCATENATED MODULE: ./server/render.js
function asyncGeneratorStep(gen, resolve, reject, _next, _throw, key, arg) { try { var info = gen[key](arg); var value = info.value; } catch (error) { reject(error); return; } if (info.done) { resolve(value); } else { Promise.resolve(value).then(_next, _throw); } }

function _asyncToGenerator(fn) { return function () { var self = this, args = arguments; return new Promise(function (resolve, reject) { var gen = fn.apply(self, args); function _next(value) { asyncGeneratorStep(gen, resolve, reject, _next, _throw, "next", value); } function _throw(err) { asyncGeneratorStep(gen, resolve, reject, _next, _throw, "throw", err); } _next(undefined); }); }; }







var statsFile = external_path_default().resolve("./buildClient/static/stats.json");
/* harmony default export */ const render = (/*#__PURE__*/(function () {
  var _ref = _asyncToGenerator( /*#__PURE__*/regeneratorRuntime.mark(function _callee(req, res, next) {
    var extractor, jsx, html, scriptTags, linkTags, styleTags, helmet;
    return regeneratorRuntime.wrap(function _callee$(_context) {
      while (1) {
        switch (_context.prev = _context.next) {
          case 0:
            _context.prev = 0;
            extractor = new lib/* ChunkExtractor */.Z7({
              statsFile: statsFile
            }); // Wrap your application using "collectChunks"

            jsx = extractor.collectChunks(createApp(App)); // Render your application

            html = (0,server.renderToString)(jsx); // You can now collect your script tags

            scriptTags = extractor.getScriptTags(); // or extractor.getScriptElements();
            // You can also collect your "preload/prefetch" links

            linkTags = extractor.getLinkTags(); // or extractor.getLinkElements();
            // And you can even collect your style tags (if you use "mini-css-extract-plugin")

            styleTags = extractor.getStyleTags(); // or extractor.getStyleElements();

            helmet = Helmet/* Helmet.renderStatic */.q.renderStatic();
            return _context.abrupt("return", res.send("<!doctype html>\n     <html ".concat(helmet.htmlAttributes.toString(), ">\n        <head>\n            ").concat(helmet.title.toString(), "\n            ").concat(helmet.meta.toString(), "\n            ").concat(helmet.link.toString(), "\n          \n            <link rel=\"shortcut icon\" href=\"data:;base64,=\">\n            ").concat(styleTags, "\n        </head>\n       \n        <body ").concat(helmet.bodyAttributes.toString(), ">\n          <div id=\"root\">").concat(html, "</div>\n          ").concat(scriptTags, "\n        </body>\n      </html>")));

          case 11:
            _context.prev = 11;
            _context.t0 = _context["catch"](0);
            console.error(_context.t0);

          case 14:
          case "end":
            return _context.stop();
        }
      }
    }, _callee, null, [[0, 11]]);
  }));

  return function (_x, _x2, _x3) {
    return _ref.apply(this, arguments);
  };
})());

var createApp = function createApp(App) {
  return /*#__PURE__*/index_js_default().createElement(App, null);
};

/***/ })

};
;