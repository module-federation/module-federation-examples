import React from 'react';
import Header from './SomeComponent';

export default () => (
  <div>
    <Header />
  </div>
);
