module.exports = () => {
  console.log('test');
};
